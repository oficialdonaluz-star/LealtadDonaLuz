// ===== DATA & STORAGE =====
const STORAGE_KEY = 'fidelidad_mvp_v1';
const MAX_STAMPS = 10;

const DEFAULT_REWARDS = [
  { id: 1, stampsRequired: 5, title: 'Café de cortesía', description: 'Un café americano o espresso gratis', icon: '☕', type: 'product' },
  { id: 2, stampsRequired: 10, title: 'Producto gratis', description: 'Elige cualquier producto del menú hasta $80', icon: '🎁', type: 'product' },
  { id: 3, stampsRequired: 8, title: 'Descuento en excursión', description: '15% de descuento en cualquier tour del mes', icon: '🚌', type: 'special' },
  { id: 4, stampsRequired: 0, title: 'Beneficio INAPAM', description: '10% adicional en todo el menú (con credencial)', icon: '👵', type: 'inapam', special: true }
];

let data = null;
let currentCustomerId = null; // For client mode
let selectedClientId = null;  // For admin detail

// ===== INIT =====
function loadData() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    data = JSON.parse(saved);
  } else {
    data = createDemoData();
    saveData();
  }
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function createDemoData() {
  const now = new Date().toISOString();
  return {
    business: {
      name: 'Café & Tours',
      subtitle: 'El Camino',
      logo: '☕'
    },
    rewards: DEFAULT_REWARDS,
    customers: [
      {
        id: 'C001',
        name: 'María González',
        phone: '55 1234 5678',
        stamps: 7,
        hasInapam: true,
        registeredAt: '2025-11-15T10:00:00.000Z',
        history: [
          { type: 'stamp', amount: 1, date: '2026-09-20T14:30:00.000Z', note: 'Visita - Café + pastel' },
          { type: 'stamp', amount: 1, date: '2026-09-18T11:15:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-09-12T16:00:00.000Z', note: 'Visita - Tour guiado' },
          { type: 'redeem', amount: -5, date: '2026-09-05T12:00:00.000Z', note: 'Canje: Café de cortesía', rewardId: 1 },
          { type: 'stamp', amount: 1, date: '2026-09-01T09:45:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-08-28T15:20:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-08-22T10:30:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-08-15T13:00:00.000Z', note: 'Primera visita' }
        ]
      },
      {
        id: 'C002',
        name: 'Carlos Ramírez',
        phone: '55 9876 5432',
        stamps: 3,
        hasInapam: false,
        registeredAt: '2026-08-01T09:00:00.000Z',
        history: [
          { type: 'stamp', amount: 1, date: '2026-09-22T18:00:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-09-10T12:30:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-08-25T11:00:00.000Z', note: 'Primera visita' }
        ]
      },
      {
        id: 'C003',
        name: 'Ana López',
        phone: '55 5555 1111',
        stamps: 10,
        hasInapam: true,
        registeredAt: '2025-10-01T10:00:00.000Z',
        history: [
          { type: 'stamp', amount: 1, date: '2026-09-24T10:00:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-09-19T15:00:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-09-14T11:30:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-09-08T14:00:00.000Z', note: 'Visita' },
          { type: 'stamp', amount: 1, date: '2026-09-02T09:15:00.000Z', note: 'Visita' }
        ]
      }
    ],
    movements: [] // Global log
  };
}

// ===== MODE SWITCHING =====
function showModeSelect() {
  document.getElementById('mode-select').classList.add('active');
  document.getElementById('client-app').classList.remove('active');
  document.getElementById('admin-app').classList.remove('active');
}

function enterClientMode() {
  // Use first customer as demo logged-in user, or create one
  if (data.customers.length === 0) {
    toast('No hay clientes. Crea uno desde el panel Admin.', 'error');
    return;
  }
  currentCustomerId = data.customers[0].id; // Demo: always first customer
  document.getElementById('mode-select').classList.remove('active');
  document.getElementById('client-app').classList.add('active');
  document.getElementById('admin-app').classList.remove('active');
  showView('inicio');
  renderClientApp();
}

function enterAdminMode() {
  document.getElementById('mode-select').classList.remove('active');
  document.getElementById('client-app').classList.remove('active');
  document.getElementById('admin-app').classList.add('active');
  showAdminView('dashboard');
  renderAdminDashboard();
}

// ===== CLIENT VIEWS =====
function showView(viewName) {
  document.querySelectorAll('#client-content .view').forEach(v => v.classList.remove('active'));
  document.getElementById('view-' + viewName).classList.add('active');
  
  document.querySelectorAll('.bottom-nav .nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.view === viewName);
  });
  
  if (viewName === 'tarjeta') renderQR();
  if (viewName === 'inicio' || viewName === 'recompensas' || viewName === 'perfil' || viewName === 'tarjeta') {
    renderClientApp();
  }
}

function getCurrentCustomer() {
  return data.customers.find(c => c.id === currentCustomerId);
}

function renderClientApp() {
  const customer = getCurrentCustomer();
  if (!customer) return;

  // Greeting
  const hour = new Date().getHours();
  let greet = '¡Hola';
  if (hour < 12) greet = '¡Buenos días';
  else if (hour < 19) greet = '¡Buenas tardes';
  else greet = '¡Buenas noches';
  document.getElementById('greeting-text').textContent = `${greet}, ${customer.name.split(' ')[0]}!`;

  // Stats
  document.getElementById('stat-stamps').textContent = customer.stamps;
  const availableRewards = data.rewards.filter(r => 
    (r.special && customer.hasInapam) || (!r.special && customer.stamps >= r.stampsRequired)
  ).length;
  document.getElementById('stat-rewards').textContent = availableRewards;
  document.getElementById('stat-visits').textContent = customer.history.filter(h => h.type === 'stamp').length;

  // Progress mini
  const pct = Math.min((customer.stamps / MAX_STAMPS) * 100, 100);
  document.getElementById('progress-mini-fill').style.width = pct + '%';
  document.getElementById('progress-mini-text').textContent = `${customer.stamps} / ${MAX_STAMPS} sellos`;

  // Rewards preview (home)
  renderRewardsList('rewards-preview', customer, true);

  // Full rewards
  renderRewardsList('rewards-full', customer, false);

  // Card
  document.getElementById('customer-id').textContent = customer.id;
  document.getElementById('card-customer-name').textContent = customer.name;
  document.getElementById('stamps-count').textContent = customer.stamps;
  renderStampsVisual(customer.stamps);

  // History (tarjeta)
  renderHistory('history-list', customer.history.slice(0, 8));

  // Profile
  document.getElementById('profile-name').textContent = customer.name;
  document.getElementById('profile-phone').textContent = customer.phone;
  document.getElementById('profile-date').textContent = formatDate(customer.registeredAt);
  document.getElementById('p-stamps').textContent = customer.stamps;
  document.getElementById('p-redeemed').textContent = customer.history.filter(h => h.type === 'redeem').length;
  renderHistory('profile-history', customer.history);
}

function renderStampsVisual(count) {
  const container = document.getElementById('stamps-visual');
  container.innerHTML = '';
  for (let i = 0; i < MAX_STAMPS; i++) {
    const stamp = document.createElement('div');
    stamp.className = 'stamp' + (i < count ? ' filled' : '');
    stamp.textContent = i < count ? '★' : '';
    container.appendChild(stamp);
  }
}

function renderRewardsList(containerId, customer, previewOnly) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  
  let rewards = [...data.rewards];
  if (previewOnly) {
    rewards = rewards.filter(r => !r.special || customer.hasInapam).slice(0, 3);
  }

  rewards.forEach(reward => {
    const isInapam = reward.special;
    const unlocked = isInapam ? customer.hasInapam : customer.stamps >= reward.stampsRequired;
    const canRedeem = unlocked && !isInapam && customer.stamps >= reward.stampsRequired;

    const card = document.createElement('div');
    card.className = 'reward-card' + (unlocked ? (canRedeem || isInapam ? ' available' : '') : ' locked');
    
    card.innerHTML = `
      <div class="reward-icon">${reward.icon}</div>
      <div class="reward-info">
        <h4>${reward.title}</h4>
        <p>${reward.description}</p>
      </div>
      <div class="reward-stamps">${isInapam ? 'INAPAM' : reward.stampsRequired + ' sellos'}</div>
    `;
    container.appendChild(card);
  });
}

function renderHistory(containerId, history) {
  const container = document.getElementById(containerId);
  if (!history || history.length === 0) {
    container.innerHTML = '<div class="empty-state">Aún no hay movimientos</div>';
    return;
  }
  
  container.innerHTML = history.map(item => {
    const isPlus = item.type === 'stamp';
    return `
      <div class="history-item">
        <div class="history-icon ${isPlus ? 'plus' : 'minus'}">${isPlus ? '➕' : '🎁'}</div>
        <div class="history-info">
          <strong>${item.note || (isPlus ? 'Sello agregado' : 'Recompensa canjeada')}</strong>
          <span>${formatDateTime(item.date)}</span>
        </div>
        <div class="history-points ${isPlus ? 'plus' : 'minus'}">
          ${isPlus ? '+' : ''}${item.amount}
        </div>
      </div>
    `;
  }).join('');
}

function renderQR() {
  const customer = getCurrentCustomer();
  if (!customer) return;
  
  const container = document.getElementById('qrcode');
  const payload = `FIDELIDAD:${customer.id}`;
  const data = encodeURIComponent(payload);
  
  // Try public QR API, with text fallback
  container.innerHTML = `
    <img src="https://api.qrserver.com/v1/create-qr-code/?size=160x160&color=0f766e&bgcolor=ffffff&margin=8&data=${data}" 
         alt="QR ${customer.id}" width="160" height="160"
         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
    <div style="display:none; width:160px; height:160px; background:#f0fdfa; border:2px dashed #0f766e; border-radius:12px; flex-direction:column; align-items:center; justify-content:center; color:#0f766e; font-size:14px; text-align:center; padding:8px;">
      <strong style="font-size:18px;">${customer.id}</strong>
      <span style="font-size:11px; margin-top:4px;">Código de cliente</span>
    </div>
  `;
}

// ===== ADMIN =====
function showAdminView(viewName) {
  document.querySelectorAll('#admin-content .view').forEach(v => v.classList.remove('active'));
  document.getElementById('admin-' + viewName).classList.add('active');
  
  if (viewName === 'dashboard') renderAdminDashboard();
  if (viewName === 'add-stamp') {
    document.getElementById('search-client').value = '';
    renderClientSearchResults(data.customers);
  }
  if (viewName === 'clients') renderAllClients();
  if (viewName === 'rewards-admin') renderAdminRewards();
}

function renderAdminDashboard() {
  document.getElementById('admin-total-clients').textContent = data.customers.length;
  
  let totalStamps = 0;
  let totalRedeems = 0;
  data.customers.forEach(c => {
    c.history.forEach(h => {
      if (h.type === 'stamp') totalStamps += h.amount;
      if (h.type === 'redeem') totalRedeems++;
    });
  });
  document.getElementById('admin-total-stamps').textContent = totalStamps;
  document.getElementById('admin-total-redeems').textContent = totalRedeems;

  // Recent movements (flatten from all customers)
  const allMovements = [];
  data.customers.forEach(c => {
    c.history.forEach(h => {
      allMovements.push({ ...h, customerName: c.name, customerId: c.id });
    });
  });
  allMovements.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  const container = document.getElementById('admin-movements');
  if (allMovements.length === 0) {
    container.innerHTML = '<div class="empty-state">Sin movimientos aún</div>';
    return;
  }
  
  container.innerHTML = allMovements.slice(0, 10).map(item => {
    const isPlus = item.type === 'stamp';
    return `
      <div class="history-item">
        <div class="history-icon ${isPlus ? 'plus' : 'minus'}">${isPlus ? '➕' : '🎁'}</div>
        <div class="history-info">
          <strong>${item.customerName}</strong>
          <span>${item.note || ''} · ${formatDateTime(item.date)}</span>
        </div>
        <div class="history-points ${isPlus ? 'plus' : 'minus'}">
          ${isPlus ? '+' : ''}${item.amount}
        </div>
      </div>
    `;
  }).join('');
}

function filterClients() {
  const q = document.getElementById('search-client').value.toLowerCase().trim();
  const filtered = data.customers.filter(c => 
    c.name.toLowerCase().includes(q) || c.id.toLowerCase().includes(q) || c.phone.includes(q)
  );
  renderClientSearchResults(filtered);
}

function renderClientSearchResults(clients) {
  const container = document.getElementById('client-search-results');
  if (clients.length === 0) {
    container.innerHTML = '<div class="empty-state">No se encontraron clientes</div>';
    return;
  }
  container.innerHTML = clients.map(c => `
    <div class="client-item" onclick="openClientDetail('${c.id}')">
      <div class="client-avatar">${c.name.charAt(0)}</div>
      <div class="client-info">
        <strong>${c.name}</strong>
        <span>${c.id} · ${c.phone}${c.hasInapam ? ' · INAPAM' : ''}</span>
      </div>
      <div class="client-stamps">${c.stamps} ★</div>
    </div>
  `).join('');
}

function renderAllClients() {
  const container = document.getElementById('all-clients');
  container.innerHTML = data.customers.map(c => `
    <div class="client-item" onclick="openClientDetail('${c.id}')">
      <div class="client-avatar">${c.name.charAt(0)}</div>
      <div class="client-info">
        <strong>${c.name}</strong>
        <span>${c.id} · ${c.phone}${c.hasInapam ? ' · 👵 INAPAM' : ''}</span>
      </div>
      <div class="client-stamps">${c.stamps} ★</div>
    </div>
  `).join('');
}

function openClientDetail(clientId) {
  selectedClientId = clientId;
  const customer = data.customers.find(c => c.id === clientId);
  if (!customer) return;

  showAdminView('client-detail');
  
  const availableRewards = data.rewards.filter(r => 
    !r.special && customer.stamps >= r.stampsRequired
  );

  const content = document.getElementById('client-detail-content');
  content.innerHTML = `
    <div class="detail-card">
      <div class="detail-name">${customer.name}</div>
      <div class="detail-meta">${customer.id} · ${customer.phone}${customer.hasInapam ? ' · 👵 INAPAM' : ''}</div>
      <div class="detail-stamps">${customer.stamps}<small> / ${MAX_STAMPS} sellos</small></div>
    </div>
    
    <div class="detail-actions">
      <button class="btn btn-primary" onclick="addStamp('${customer.id}')">
        ➕ Agregar 1 sello
      </button>
      ${availableRewards.map(r => `
        <button class="btn btn-success" onclick="redeemReward('${customer.id}', ${r.id})">
          🎁 Canjear: ${r.title} (${r.stampsRequired} sellos)
        </button>
      `).join('')}
      ${customer.stamps === 0 ? '<p class="empty-state">Sin sellos para canjear</p>' : ''}
    </div>
    
    <h3 class="section-title" style="margin-top:24px">Historial del cliente</h3>
    <div id="detail-history" class="history-list"></div>
  `;
  
  renderHistory('detail-history', customer.history);
}

function addStamp(clientId) {
  const customer = data.customers.find(c => c.id === clientId);
  if (!customer) return;
  
  if (customer.stamps >= MAX_STAMPS) {
    toast('El cliente ya tiene el máximo de sellos. ¡Canjea una recompensa!', 'error');
    return;
  }
  
  customer.stamps += 1;
  customer.history.unshift({
    type: 'stamp',
    amount: 1,
    date: new Date().toISOString(),
    note: 'Visita registrada'
  });
  
  saveData();
  toast(`¡Sello agregado a ${customer.name}! Ahora tiene ${customer.stamps} sellos`, 'success');
  openClientDetail(clientId);
  renderAdminDashboard();
}

function redeemReward(clientId, rewardId) {
  const customer = data.customers.find(c => c.id === clientId);
  const reward = data.rewards.find(r => r.id === rewardId);
  if (!customer || !reward) return;
  
  if (customer.stamps < reward.stampsRequired) {
    toast('Sellos insuficientes', 'error');
    return;
  }
  
  customer.stamps -= reward.stampsRequired;
  customer.history.unshift({
    type: 'redeem',
    amount: -reward.stampsRequired,
    date: new Date().toISOString(),
    note: `Canje: ${reward.title}`,
    rewardId: reward.id
  });
  
  saveData();
  toast(`¡Recompensa canjeada! ${reward.title}`, 'success');
  openClientDetail(clientId);
  renderAdminDashboard();
}

function createClient(e) {
  e.preventDefault();
  const name = document.getElementById('new-name').value.trim();
  const phone = document.getElementById('new-phone').value.trim();
  const hasInapam = document.getElementById('new-inapam').value === 'yes';
  
  if (!name || !phone) {
    toast('Completa todos los campos', 'error');
    return;
  }
  
  // Generate ID
  const nextNum = data.customers.length + 1;
  const id = 'C' + String(nextNum).padStart(3, '0');
  
  const newCustomer = {
    id,
    name,
    phone,
    stamps: 0,
    hasInapam,
    registeredAt: new Date().toISOString(),
    history: []
  };
  
  data.customers.push(newCustomer);
  saveData();
  
  toast(`Cliente ${name} creado con éxito (${id})`, 'success');
  document.getElementById('new-client-form').reset();
  showAdminView('dashboard');
}

function renderAdminRewards() {
  const container = document.getElementById('admin-rewards-list');
  container.innerHTML = data.rewards.map(r => `
    <div class="reward-card">
      <div class="reward-icon">${r.icon}</div>
      <div class="reward-info">
        <h4>${r.title}</h4>
        <p>${r.description}</p>
      </div>
      <div class="reward-stamps">${r.special ? 'INAPAM' : r.stampsRequired + ' sellos'}</div>
    </div>
  `).join('');
}

// ===== UTILS =====
function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatDateTime(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('es-MX', { 
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' 
  });
}

function toast(msg, type = '') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast show' + (type ? ' ' + type : '');
  setTimeout(() => {
    el.classList.remove('show');
  }, 3000);
}

function resetDemoData() {
  if (confirm('¿Seguro que quieres reiniciar todos los datos de demostración?')) {
    localStorage.removeItem(STORAGE_KEY);
    data = createDemoData();
    saveData();
    currentCustomerId = data.customers[0].id;
    toast('Datos reiniciados', 'success');
    renderClientApp();
  }
}

// ===== PWA / SERVICE WORKER =====
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(err => {
      console.log('SW registration failed:', err);
    });
  });
}

// ===== START =====
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  // Show mode select by default
});
